<?php

return [
    'load_styles' => true,
];