<?php

// config for IbrahimBougaoua/FilamentRatingStar
return [
    'stars' => [
        'star1' => '1',
        'star2' => '2',
        'star3' => '3',
        'star4' => '4',
        'star5' => '5',
    ]
];
