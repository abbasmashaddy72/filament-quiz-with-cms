<?php

return [
    'renew_password_days_period' => env('FILAMENT_RENEW_PASSWORD_DAYS_PERIOD', 90)
];