<?php

use Coolsam\FilamentFlatpickr\Enums\FlatpickrTheme;

return [
    'default_theme' => FlatpickrTheme::DEFAULT,
];
