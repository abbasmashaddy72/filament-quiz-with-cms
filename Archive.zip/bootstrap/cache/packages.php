<?php return array (
  'akaunting/laravel-firewall' => 
  array (
    'providers' => 
    array (
      0 => 'Akaunting\\Firewall\\Provider',
    ),
  ),
  'amendozaaguiar/filament-route-statistics' => 
  array (
    'providers' => 
    array (
      0 => 'Amendozaaguiar\\FilamentRouteStatistics\\FilamentRouteStatisticsServiceProvider',
    ),
  ),
  'andreiio/blade-remix-icon' => 
  array (
    'providers' => 
    array (
      0 => 'AndreiIonita\\BladeRemixIcon\\BladeRemixIconServiceProvider',
    ),
  ),
  'anourvalar/eloquent-serialize' => 
  array (
    'aliases' => 
    array (
      'EloquentSerialize' => 'AnourValar\\EloquentSerialize\\Facades\\EloquentSerializeFacade',
    ),
  ),
  'archtechx/laravel-seo' => 
  array (
    'providers' => 
    array (
      0 => 'ArchTech\\SEO\\SEOServiceProvider',
    ),
  ),
  'awcodes/filament-addons' => 
  array (
    'providers' => 
    array (
      0 => 'FilamentAddons\\FilamentAddonsServiceProvider',
    ),
  ),
  'awcodes/filament-curator' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\Curator\\CuratorServiceProvider',
    ),
  ),
  'awcodes/filament-quick-create' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\FilamentQuickCreate\\QuickCreateServiceProvider',
    ),
  ),
  'awcodes/filament-tiptap-editor' => 
  array (
    'providers' => 
    array (
      0 => 'FilamentTiptapEditor\\FilamentTiptapEditorServiceProvider',
    ),
  ),
  'awcodes/filament-versions' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\FilamentVersions\\FilamentVersionsServiceProvider',
    ),
  ),
  'awcodes/light-switch' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\LightSwitch\\LightSwitchServiceProvider',
    ),
  ),
  'awcodes/overlook' => 
  array (
    'providers' => 
    array (
      0 => 'Awcodes\\Overlook\\OverlookServiceProvider',
    ),
  ),
  'beyondcode/laravel-query-detector' => 
  array (
    'providers' => 
    array (
      0 => 'BeyondCode\\QueryDetector\\QueryDetectorServiceProvider',
    ),
  ),
  'bezhansalleh/filament-exceptions' => 
  array (
    'aliases' => 
    array (
      'FilamentExceptions' => 'BezhanSalleh\\FilamentExceptions\\Facades\\FilamentExceptions',
    ),
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentExceptions\\FilamentExceptionsServiceProvider',
    ),
  ),
  'bezhansalleh/filament-language-switch' => 
  array (
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentLanguageSwitch\\FilamentLanguageSwitchServiceProvider',
    ),
  ),
  'bezhansalleh/filament-shield' => 
  array (
    'aliases' => 
    array (
      'FilamentShield' => 'BezhanSalleh\\FilamentShield\\Facades\\FilamentShield',
    ),
    'providers' => 
    array (
      0 => 'BezhanSalleh\\FilamentShield\\FilamentShieldServiceProvider',
    ),
  ),
  'bilfeldt/laravel-correlation-id' => 
  array (
    'providers' => 
    array (
      0 => 'Bilfeldt\\CorrelationId\\CorrelationIdServiceProvider',
    ),
  ),
  'bilfeldt/laravel-request-logger' => 
  array (
    'aliases' => 
    array (
      'RequestLogger' => 'Bilfeldt\\RequestLogger\\RequestLoggerFacade',
    ),
    'providers' => 
    array (
      0 => 'Bilfeldt\\RequestLogger\\RequestLoggerServiceProvider',
    ),
  ),
  'bilfeldt/laravel-route-statistics' => 
  array (
    'providers' => 
    array (
      0 => 'Bilfeldt\\LaravelRouteStatistics\\LaravelRouteStatisticsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-heroicons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Heroicons\\BladeHeroiconsServiceProvider',
    ),
  ),
  'blade-ui-kit/blade-icons' => 
  array (
    'providers' => 
    array (
      0 => 'BladeUI\\Icons\\BladeIconsServiceProvider',
    ),
  ),
  'brickx/maintenance-switch' => 
  array (
    'providers' => 
    array (
      0 => 'Brickx\\MaintenanceSwitch\\MaintenanceSwitchServiceProvider',
    ),
  ),
  'codeat3/blade-clarity-icons' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeClarityIcons\\BladeClarityIconsServiceProvider',
    ),
  ),
  'codeat3/blade-iconpark' => 
  array (
    'providers' => 
    array (
      0 => 'Codeat3\\BladeIconpark\\BladeIconparkServiceProvider',
    ),
  ),
  'coolsam/flatpickr' => 
  array (
    'aliases' => 
    array (
      'FilamentFlatpickr' => 'Coolsam\\FilamentFlatpickr\\Facades\\FilamentFlatpickr',
    ),
    'providers' => 
    array (
      0 => 'Coolsam\\FilamentFlatpickr\\FilamentFlatpickrServiceProvider',
    ),
  ),
  'croustibat/filament-jobs-monitor' => 
  array (
    'aliases' => 
    array (
      'QueueMonitor' => 'Croustibat\\FilamentJobsMonitor\\QueueMonitorProvider\\Facade',
    ),
    'providers' => 
    array (
      0 => 'Croustibat\\FilamentJobsMonitor\\FilamentJobsMonitorServiceProvider',
      1 => 'Croustibat\\FilamentJobsMonitor\\QueueMonitorProvider',
    ),
  ),
  'filament/actions' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Actions\\ActionsServiceProvider',
    ),
  ),
  'filament/filament' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\FilamentServiceProvider',
    ),
  ),
  'filament/forms' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Forms\\FormsServiceProvider',
    ),
  ),
  'filament/infolists' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Infolists\\InfolistsServiceProvider',
    ),
  ),
  'filament/notifications' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Notifications\\NotificationsServiceProvider',
    ),
  ),
  'filament/spatie-laravel-settings-plugin' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\SpatieLaravelSettingsPluginServiceProvider',
    ),
  ),
  'filament/spatie-laravel-translatable-plugin' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\SpatieLaravelTranslatablePluginServiceProvider',
    ),
  ),
  'filament/support' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Support\\SupportServiceProvider',
    ),
  ),
  'filament/tables' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Tables\\TablesServiceProvider',
    ),
  ),
  'filament/widgets' => 
  array (
    'providers' => 
    array (
      0 => 'Filament\\Widgets\\WidgetsServiceProvider',
    ),
  ),
  'filipfonal/filament-log-manager' => 
  array (
    'aliases' => 
    array (
      'FilamentLogManager' => 'FilipFonal\\FilamentLogManager\\Facades\\FilamentLogManager',
    ),
    'providers' => 
    array (
      0 => 'FilipFonal\\FilamentLogManager\\FilamentLogManagerServiceProvider',
    ),
  ),
  'flowframe/laravel-trend' => 
  array (
    'aliases' => 
    array (
      'Trend' => 'Flowframe\\Trend\\TrendFacade',
    ),
    'providers' => 
    array (
      0 => 'Flowframe\\Trend\\TrendServiceProvider',
    ),
  ),
  'guava/filament-icon-picker' => 
  array (
    'providers' => 
    array (
      0 => 'Guava\\FilamentIconPicker\\FilamentIconPickerServiceProvider',
    ),
  ),
  'hasnayeen/themes' => 
  array (
    'providers' => 
    array (
      0 => 'Hasnayeen\\Themes\\ThemesServiceProvider',
    ),
  ),
  'husam-tariq/filament-timepicker' => 
  array (
    'aliases' => 
    array (
      'FilamentTimePicker' => 'HusamTariq\\FilamentTimePicker\\Facades\\FilamentTimePicker',
    ),
    'providers' => 
    array (
      0 => 'HusamTariq\\FilamentTimePicker\\FilamentTimePickerServiceProvider',
    ),
  ),
  'ibrahimbougaoua/filament-rating-star' => 
  array (
    'aliases' => 
    array (
      'FilamentRatingStar' => 'IbrahimBougaoua\\FilamentRatingStar\\Facades\\FilamentRatingStar',
    ),
    'providers' => 
    array (
      0 => 'IbrahimBougaoua\\FilamentRatingStar\\FilamentRatingStarServiceProvider',
    ),
  ),
  'imanghafoori/laravel-microscope' => 
  array (
    'providers' => 
    array (
      0 => 'Imanghafoori\\LaravelMicroscope\\LaravelMicroscopeServiceProvider',
    ),
  ),
  'imanghafoori/smart-realtime-facades' => 
  array (
    'providers' => 
    array (
      0 => 'Imanghafoori\\RealtimeFacades\\SmartRealTimeFacadesProvider',
    ),
  ),
  'intervention/image' => 
  array (
    'aliases' => 
    array (
      'Image' => 'Intervention\\Image\\Facades\\Image',
    ),
    'providers' => 
    array (
      0 => 'Intervention\\Image\\ImageServiceProvider',
    ),
  ),
  'jeffgreco13/filament-breezy' => 
  array (
    'aliases' => 
    array (
      'FilamentBreezy' => 'Jeffgreco13\\FilamentBreezy\\Facades\\FilamentBreezy',
    ),
    'providers' => 
    array (
      0 => 'Jeffgreco13\\FilamentBreezy\\FilamentBreezyServiceProvider',
    ),
  ),
  'jenssegers/agent' => 
  array (
    'aliases' => 
    array (
      'Agent' => 'Jenssegers\\Agent\\Facades\\Agent',
    ),
    'providers' => 
    array (
      0 => 'Jenssegers\\Agent\\AgentServiceProvider',
    ),
  ),
  'kenepa/resource-lock' => 
  array (
    'aliases' => 
    array (
      'ResourceLock' => 'Kenepa\\ResourceLock\\Facades\\ResourceLock',
    ),
    'providers' => 
    array (
      0 => 'Kenepa\\ResourceLock\\ResourceLockServiceProvider',
    ),
  ),
  'kirschbaum-development/eloquent-power-joins' => 
  array (
    'providers' => 
    array (
      0 => 'Kirschbaum\\PowerJoins\\PowerJoinsServiceProvider',
    ),
  ),
  'lab404/laravel-impersonate' => 
  array (
    'providers' => 
    array (
      0 => 'Lab404\\Impersonate\\ImpersonateServiceProvider',
    ),
  ),
  'lara-zeus/accordion' => 
  array (
    'providers' => 
    array (
      0 => 'LaraZeus\\Accordion\\AccordionServiceProvider',
    ),
  ),
  'lara-zeus/bolt' => 
  array (
    'aliases' => 
    array (
      'Bolt' => 'LaraZeus\\Bolt\\Facades\\Bolt',
    ),
    'providers' => 
    array (
      0 => 'LaraZeus\\Bolt\\BoltServiceProvider',
    ),
  ),
  'lara-zeus/core' => 
  array (
    'aliases' => 
    array (
      'Core' => 'LaraZeus\\Core\\CoreFacade',
    ),
    'providers' => 
    array (
      0 => 'LaraZeus\\Core\\CoreServiceProvider',
    ),
  ),
  'lara-zeus/filament-plugin-tools' => 
  array (
    'providers' => 
    array (
      0 => 'LaraZeus\\FilamentPluginTools\\FilamentPluginToolsServiceProvider',
    ),
  ),
  'lara-zeus/list-group' => 
  array (
    'providers' => 
    array (
      0 => 'LaraZeus\\ListGroup\\ListGroupServiceProvider',
    ),
  ),
  'lara-zeus/popover' => 
  array (
    'providers' => 
    array (
      0 => 'LaraZeus\\Popover\\PopoverServiceProvider',
    ),
  ),
  'lara-zeus/qr' => 
  array (
    'providers' => 
    array (
      0 => 'LaraZeus\\Qr\\QrServiceProvider',
    ),
  ),
  'laravel/sail' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sail\\SailServiceProvider',
    ),
  ),
  'laravel/sanctum' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Sanctum\\SanctumServiceProvider',
    ),
  ),
  'laravel/tinker' => 
  array (
    'providers' => 
    array (
      0 => 'Laravel\\Tinker\\TinkerServiceProvider',
    ),
  ),
  'livewire/livewire' => 
  array (
    'aliases' => 
    array (
      'Livewire' => 'Livewire\\Livewire',
    ),
    'providers' => 
    array (
      0 => 'Livewire\\LivewireServiceProvider',
    ),
  ),
  'maatwebsite/excel' => 
  array (
    'aliases' => 
    array (
      'Excel' => 'Maatwebsite\\Excel\\Facades\\Excel',
    ),
    'providers' => 
    array (
      0 => 'Maatwebsite\\Excel\\ExcelServiceProvider',
    ),
  ),
  'malzariey/filament-daterangepicker-filter' => 
  array (
    'aliases' => 
    array (
      'FilamentDaterangepickerFilter' => 'Malzariey\\FilamentDaterangepickerFilter\\Facades\\FilamentDaterangepickerFilter',
    ),
    'providers' => 
    array (
      0 => 'Malzariey\\FilamentDaterangepickerFilter\\FilamentDaterangepickerFilterServiceProvider',
    ),
  ),
  'marjose123/filament-lockscreen' => 
  array (
    'providers' => 
    array (
      0 => 'lockscreen\\FilamentLockscreen\\FilamentLockscreenServiceProvider',
    ),
  ),
  'mcamara/laravel-localization' => 
  array (
    'aliases' => 
    array (
      'LaravelLocalization' => 'Mcamara\\LaravelLocalization\\Facades\\LaravelLocalization',
    ),
    'providers' => 
    array (
      0 => 'Mcamara\\LaravelLocalization\\LaravelLocalizationServiceProvider',
    ),
  ),
  'nesbot/carbon' => 
  array (
    'providers' => 
    array (
      0 => 'Carbon\\Laravel\\ServiceProvider',
    ),
  ),
  'nunomaduro/collision' => 
  array (
    'providers' => 
    array (
      0 => 'NunoMaduro\\Collision\\Adapters\\Laravel\\CollisionServiceProvider',
    ),
  ),
  'nunomaduro/termwind' => 
  array (
    'providers' => 
    array (
      0 => 'Termwind\\Laravel\\TermwindServiceProvider',
    ),
  ),
  'omar-haris/filament-timezone-field' => 
  array (
    'aliases' => 
    array (
      'FilamentTimezoneField' => 'OmarHaris\\FilamentTimezoneField\\Facades\\FilamentTimezoneField',
    ),
    'providers' => 
    array (
      0 => 'OmarHaris\\FilamentTimezoneField\\FilamentTimezoneFieldServiceProvider',
    ),
  ),
  'owen-it/laravel-auditing' => 
  array (
    'providers' => 
    array (
      0 => 'OwenIt\\Auditing\\AuditingServiceProvider',
    ),
  ),
  'parfaitementweb/filament-country-field' => 
  array (
    'providers' => 
    array (
      0 => 'Parfaitementweb\\FilamentCountryField\\FilamentCountryFieldServiceProvider',
    ),
  ),
  'propaganistas/laravel-phone' => 
  array (
    'providers' => 
    array (
      0 => 'Propaganistas\\LaravelPhone\\PhoneServiceProvider',
    ),
  ),
  'pxlrbt/filament-environment-indicator' => 
  array (
    'providers' => 
    array (
      0 => '\\pxlrbt\\FilamentEnvironmentIndicator\\FilamentEnvironmentIndicatorServiceProvider',
    ),
  ),
  'pxlrbt/filament-excel' => 
  array (
    'providers' => 
    array (
      0 => 'pxlrbt\\FilamentExcel\\FilamentExcelServiceProvider',
    ),
  ),
  'rappasoft/laravel-authentication-log' => 
  array (
    'providers' => 
    array (
      0 => 'Rappasoft\\LaravelAuthenticationLog\\LaravelAuthenticationLogServiceProvider',
    ),
  ),
  'rickdbcn/filament-email' => 
  array (
    'aliases' => 
    array (
      'FilamentEmail' => 'RickDBCN\\FilamentEmail\\Facades\\FilamentEmail',
    ),
    'providers' => 
    array (
      0 => 'RickDBCN\\FilamentEmail\\FilamentEmailServiceProvider',
    ),
  ),
  'ryangjchandler/blade-capture-directive' => 
  array (
    'aliases' => 
    array (
      'BladeCaptureDirective' => 'RyanChandler\\BladeCaptureDirective\\Facades\\BladeCaptureDirective',
    ),
    'providers' => 
    array (
      0 => 'RyanChandler\\BladeCaptureDirective\\BladeCaptureDirectiveServiceProvider',
    ),
  ),
  'ryangjchandler/blade-tabler-icons' => 
  array (
    'providers' => 
    array (
      0 => 'RyanChandler\\TablerIcons\\BladeTablerIconsServiceProvider',
    ),
  ),
  'shuvroroy/filament-spatie-laravel-backup' => 
  array (
    'providers' => 
    array (
      0 => 'ShuvroRoy\\FilamentSpatieLaravelBackup\\FilamentSpatieLaravelBackupServiceProvider',
    ),
  ),
  'shuvroroy/filament-spatie-laravel-health' => 
  array (
    'providers' => 
    array (
      0 => 'ShuvroRoy\\FilamentSpatieLaravelHealth\\FilamentSpatieLaravelHealthServiceProvider',
    ),
  ),
  'simplesoftwareio/simple-qrcode' => 
  array (
    'aliases' => 
    array (
      'QrCode' => 'SimpleSoftwareIO\\QrCode\\Facades\\QrCode',
    ),
    'providers' => 
    array (
      0 => 'SimpleSoftwareIO\\QrCode\\QrCodeServiceProvider',
    ),
  ),
  'solution-forest/filament-firewall' => 
  array (
    'aliases' => 
    array (
      'FilamentFirewall' => 'SolutionForest\\FilamentFirewall\\Facades\\FilamentFirewall',
    ),
    'providers' => 
    array (
      0 => 'SolutionForest\\FilamentFirewall\\FilamentFirewallServiceProvider',
    ),
  ),
  'solution-forest/filament-simplelightbox' => 
  array (
    'aliases' => 
    array (
      'FilamentSimpleLightBox' => 'SolutionForest\\FilamentSimpleLightBox\\Facades\\FilamentSimpleLightBox',
    ),
    'providers' => 
    array (
      0 => 'SolutionForest\\FilamentSimpleLightBox\\FilamentSimpleLightBoxServiceProvider',
    ),
  ),
  'spatie/eloquent-sortable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\EloquentSortable\\EloquentSortableServiceProvider',
    ),
  ),
  'spatie/laravel-backup' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Backup\\BackupServiceProvider',
    ),
  ),
  'spatie/laravel-health' => 
  array (
    'aliases' => 
    array (
      'Health' => 'Spatie\\Health\\Facades\\Health',
    ),
    'providers' => 
    array (
      0 => 'Spatie\\Health\\HealthServiceProvider',
    ),
  ),
  'spatie/laravel-ignition' => 
  array (
    'aliases' => 
    array (
      'Flare' => 'Spatie\\LaravelIgnition\\Facades\\Flare',
    ),
    'providers' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\IgnitionServiceProvider',
    ),
  ),
  'spatie/laravel-permission' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Permission\\PermissionServiceProvider',
    ),
  ),
  'spatie/laravel-settings' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\LaravelSettings\\LaravelSettingsServiceProvider',
    ),
  ),
  'spatie/laravel-signal-aware-command' => 
  array (
    'aliases' => 
    array (
      'Signal' => 'Spatie\\SignalAwareCommand\\Facades\\Signal',
    ),
    'providers' => 
    array (
      0 => 'Spatie\\SignalAwareCommand\\SignalAwareCommandServiceProvider',
    ),
  ),
  'spatie/laravel-sitemap' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Sitemap\\SitemapServiceProvider',
    ),
  ),
  'spatie/laravel-tags' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Tags\\TagsServiceProvider',
    ),
  ),
  'spatie/laravel-translatable' => 
  array (
    'providers' => 
    array (
      0 => 'Spatie\\Translatable\\TranslatableServiceProvider',
    ),
  ),
  'stechstudio/filament-impersonate' => 
  array (
    'providers' => 
    array (
      0 => 'STS\\FilamentImpersonate\\FilamentImpersonateServiceProvider',
    ),
  ),
  'tapp/filament-auditing' => 
  array (
    'providers' => 
    array (
      0 => 'Tapp\\FilamentAuditing\\FilamentAuditingServiceProvider',
    ),
  ),
  'tapp/filament-authentication-log' => 
  array (
    'providers' => 
    array (
      0 => 'Tapp\\FilamentAuthenticationLog\\FilamentAuthenticationLogServiceProvider',
    ),
  ),
  'torann/geoip' => 
  array (
    'aliases' => 
    array (
      'GeoIP' => 'Torann\\GeoIP\\Facades\\GeoIP',
    ),
    'providers' => 
    array (
      0 => 'Torann\\GeoIP\\GeoIPServiceProvider',
    ),
  ),
  'wireui/wireui' => 
  array (
    'aliases' => 
    array (
    ),
    'providers' => 
    array (
      0 => 'WireUi\\Providers\\WireUiServiceProvider',
    ),
  ),
  'yebor974/filament-renew-password' => 
  array (
    'providers' => 
    array (
      0 => 'Yebor974\\Filament\\RenewPassword\\FilamentRenewPasswordServiceProvider',
    ),
  ),
  'ysfkaya/filament-phone-input' => 
  array (
    'providers' => 
    array (
      0 => 'Ysfkaya\\FilamentPhoneInput\\FilamentPhoneInputServiceProvider',
    ),
  ),
);