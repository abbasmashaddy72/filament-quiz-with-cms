<span class="py-1 px-3 rounded-full bg-secondary-500 text-white">
    {{ $slot }}
</span>