<div class="render-block render-block__rich-text">
    <x-prose>
        {!! $content !!}
    </x-prose>
</div>
