<div class="grid">
    {{ $slot }}
</div>
