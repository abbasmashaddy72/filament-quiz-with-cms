<div class="text-danger-500">
    <code>
         {{ '@' }}livewire('menu', ['key' => "{{ $getState() }}"])
    </code>
</div>
