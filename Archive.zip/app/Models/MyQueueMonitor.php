<?php

namespace App\Models;

use \Croustibat\FilamentJobsMonitor\Models\QueueMonitor as CroustibatQueueMonitor;

class MyQueueMonitor extends CroustibatQueueMonitor
{
}
