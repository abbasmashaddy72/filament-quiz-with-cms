<?php

namespace App\Utils;

use Exception;

class AdderException extends Exception
{
}
