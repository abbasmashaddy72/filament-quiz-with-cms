<?php if($media): ?>
    <?php if(str($media->type)->contains('image')): ?>
        <img
            src="<?php echo e($source); ?>"
            alt="<?php echo e($attributes->get('alt', $media->alt)); ?>"
            <?php if($width && $height): ?>
                width="<?php echo e($width); ?>"
                height="<?php echo e($height); ?>"
            <?php else: ?>
                width="<?php echo e($media->width); ?>"
                height="<?php echo e($media->height); ?>"
            <?php endif; ?>
            <?php if($sourceSet): ?>
                srcset="<?php echo e($sourceSet); ?>"
                sizes="<?php echo e($sizes); ?>"
            <?php endif; ?>
            <?php echo e($attributes->filter(fn ($attr) => $attr !== '')); ?>

        />
    <?php else: ?>
        <?php if (isset($component)) { $__componentOriginaldf8a712998df2199f6fd7a9afac78c10 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf8a712998df2199f6fd7a9afac78c10 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'curator::components.document-image','data' => ['label' => ''.e($media->name).'','iconSize' => 'xl','attributes' => $attributes->merge(['class' => 'p-4'])]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('curator::document-image'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['label' => ''.e($media->name).'','icon-size' => 'xl','attributes' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($attributes->merge(['class' => 'p-4']))]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf8a712998df2199f6fd7a9afac78c10)): ?>
<?php $attributes = $__attributesOriginaldf8a712998df2199f6fd7a9afac78c10; ?>
<?php unset($__attributesOriginaldf8a712998df2199f6fd7a9afac78c10); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf8a712998df2199f6fd7a9afac78c10)): ?>
<?php $component = $__componentOriginaldf8a712998df2199f6fd7a9afac78c10; ?>
<?php unset($__componentOriginaldf8a712998df2199f6fd7a9afac78c10); ?>
<?php endif; ?>
    <?php endif; ?>
<?php endif; ?>
<?php /**PATH /home/abbasmashaddy72/Documents/Project-Sites/Testing/cms-quiz/vendor/awcodes/filament-curator/src/../resources/views/components/glider.blade.php ENDPATH**/ ?>