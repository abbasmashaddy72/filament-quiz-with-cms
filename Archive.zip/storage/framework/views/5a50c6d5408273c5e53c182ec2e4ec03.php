<a href="#site-main-content" class="sr-only focus:not-sr-only focus:fixed top-2 left-2 z-40">
    <span class="py-3 px-4 bg-accent-700 text-white rounded-sm block">
        <?php echo e(__('app.skip_link')); ?>

    </span>
</a>
<?php /**PATH /home/abbasmashaddy72/Documents/Project-Sites/Testing/cms-quiz/resources/views/components/skip-link.blade.php ENDPATH**/ ?>