<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'loading' => 'eager',
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'loading' => 'eager',
]); ?>
<?php foreach (array_filter(([
    'loading' => 'eager',
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<aside
    class="relative flex items-center justify-center <?php if(Route::currentRouteName() === 'welcome'): ?> min-h-[80vh] <?php else: ?> min-h-[35vh] <?php endif; ?> pt-20">
    <?php if($type == 'image' && ($media || $cta)): ?>
        <div class="absolute inset-0 bg-slate-950/85"></div>
        <?php if (isset($component)) { $__componentOriginal2d62a2f0e3650962aee0f8158be82357 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d62a2f0e3650962aee0f8158be82357 = $attributes; } ?>
<?php $component = Awcodes\Curator\View\Components\Glider::resolve(['media' => $media->id ?? app(\App\Settings\SitesSettings::class)->no_image,'srcset' => ['1200w', '1024w', '640w'],'sizes' => '(max-width: 1200px) 100vw, 1024px','height' => ''.e($media->height).'','width' => ''.e($media->width).''] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('curator-glider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Awcodes\Curator\View\Components\Glider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'absolute inset-0 z-0 object-cover w-full h-full opacity-20']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d62a2f0e3650962aee0f8158be82357)): ?>
<?php $attributes = $__attributesOriginal2d62a2f0e3650962aee0f8158be82357; ?>
<?php unset($__attributesOriginal2d62a2f0e3650962aee0f8158be82357); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d62a2f0e3650962aee0f8158be82357)): ?>
<?php $component = $__componentOriginal2d62a2f0e3650962aee0f8158be82357; ?>
<?php unset($__componentOriginal2d62a2f0e3650962aee0f8158be82357); ?>
<?php endif; ?>
        <div class="container z-10 hero">
            <?php if(Route::currentRouteName() == 'welcome'): ?>
                <?php if (isset($component)) { $__componentOriginala82827a9b425f919fd1451742c5ca6a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala82827a9b425f919fd1451742c5ca6a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.prose','data' => ['class' => 'md:w-4/5']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('prose'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'md:w-4/5']); ?>
                    <?php echo $cta; ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala82827a9b425f919fd1451742c5ca6a7)): ?>
<?php $attributes = $__attributesOriginala82827a9b425f919fd1451742c5ca6a7; ?>
<?php unset($__attributesOriginala82827a9b425f919fd1451742c5ca6a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala82827a9b425f919fd1451742c5ca6a7)): ?>
<?php $component = $__componentOriginala82827a9b425f919fd1451742c5ca6a7; ?>
<?php unset($__componentOriginala82827a9b425f919fd1451742c5ca6a7); ?>
<?php endif; ?>
            <?php else: ?>
                <?php if (isset($component)) { $__componentOriginala82827a9b425f919fd1451742c5ca6a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala82827a9b425f919fd1451742c5ca6a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.prose','data' => ['class' => 'text-3xl font-bold text-center']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('prose'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'text-3xl font-bold text-center']); ?>
                    <?php echo $cta; ?>

                 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala82827a9b425f919fd1451742c5ca6a7)): ?>
<?php $attributes = $__attributesOriginala82827a9b425f919fd1451742c5ca6a7; ?>
<?php unset($__attributesOriginala82827a9b425f919fd1451742c5ca6a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala82827a9b425f919fd1451742c5ca6a7)): ?>
<?php $component = $__componentOriginala82827a9b425f919fd1451742c5ca6a7; ?>
<?php unset($__componentOriginala82827a9b425f919fd1451742c5ca6a7); ?>
<?php endif; ?>
            <?php endif; ?>
        </div>
    <?php elseif($type == 'oembed' && ($media || $cta)): ?>
        <?php
            $styles = $media['responsive'] ? "aspect-ratio: {$media['width']} / {$media['height']}; width: 100%; height: auto;" : null;
            $params = [
                'autoplay' => $media['autoplay'] ? 1 : 0,
                'loop' => $media['loop'] ? 1 : 0,
                'title' => $media['show_title'] ? 1 : 0,
                'byline' => $media['byline'] ? 1 : 0,
                'portrait' => $media['portrait'] ? 1 : 0,
            ];
        ?>
        <div class="container z-10 hero">
            <?php if (isset($component)) { $__componentOriginala82827a9b425f919fd1451742c5ca6a7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginala82827a9b425f919fd1451742c5ca6a7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.prose','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('prose'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
                <?php echo $cta; ?>

             <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginala82827a9b425f919fd1451742c5ca6a7)): ?>
<?php $attributes = $__attributesOriginala82827a9b425f919fd1451742c5ca6a7; ?>
<?php unset($__attributesOriginala82827a9b425f919fd1451742c5ca6a7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginala82827a9b425f919fd1451742c5ca6a7)): ?>
<?php $component = $__componentOriginala82827a9b425f919fd1451742c5ca6a7; ?>
<?php unset($__componentOriginala82827a9b425f919fd1451742c5ca6a7); ?>
<?php endif; ?>
        </div>

        <div class="container z-10 py-8">
            <iframe src="<?php echo e($media['embed_url']); ?>?<?php echo e(http_build_query($params)); ?>"
                width="<?php echo e($media['responsive'] ? $media['width'] : ($media['width'] ?: '640')); ?>"
                height="<?php echo e($media['responsive'] ? $media['height'] : ($media['height'] ?: '480')); ?>" frameborder="0"
                allow="autoplay; fullscreen; picture-in-picture" allowfullscreen style="<?php echo e($styles); ?>"></iframe>
        </div>
    <?php else: ?>
        <?php echo e($slot); ?>

    <?php endif; ?>
</aside>
<?php /**PATH /home/abbasmashaddy72/Documents/Project-Sites/Testing/cms-quiz/resources/views/components/hero.blade.php ENDPATH**/ ?>