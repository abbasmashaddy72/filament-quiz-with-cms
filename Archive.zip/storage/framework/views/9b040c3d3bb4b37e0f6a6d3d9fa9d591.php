<div <?php echo e($attributes->merge([
    'class' => 'prose max-w-full prose-invert',
])); ?>>
    <?php echo $slot; ?>

</div>
<?php /**PATH /home/abbasmashaddy72/Documents/Project-Sites/Testing/cms-quiz/resources/views/components/prose.blade.php ENDPATH**/ ?>