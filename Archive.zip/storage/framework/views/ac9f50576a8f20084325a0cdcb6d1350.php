<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag; ?>
<?php foreach($attributes->onlyProps([
    'meta' => [],
]) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $attributes = $attributes->exceptProps([
    'meta' => [],
]); ?>
<?php foreach (array_filter(([
    'meta' => [],
]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
} ?>
<?php $__defined_vars = get_defined_vars(); ?>
<?php foreach ($attributes as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
} ?>
<?php unset($__defined_vars); ?>

<?php
    $title = $meta->title ? $meta->title . ' | ' . config('app.name') : config('app.name');
    $description = $meta->description ? $meta->description : config('app.description');
    $robots = $meta->robots ? 'index,follow' : 'noindex,nofollow';
    $ogImage = $meta->ogImage ? $meta->ogImage : null;

    $fontConfig = config('main.font');
    if (!empty($fontConfig) && !empty($fontConfig['url']) && !empty($fontConfig['family'])) {
        $fontsUrl = $fontConfig['url'];
        $fontFamily = $fontConfig['family'];
    }
?>

<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>" class="h-full light scroll-smooth"
    dir="<?php echo e(LaravelLocalization::getCurrentLocaleDirection()); ?>">

<head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
    <link rel="icon" href="/favicon.svg" type="image/svg+xml">

    <title><?php echo e($title); ?></title>
    <meta name="description" content="<?php echo e($description); ?>" />
    <meta name="robots" content="<?php echo e($robots); ?>" />

    <link rel="canonical" href="<?php echo e(trailing_slash_it(url()->current())); ?>">

    <!-- Open Graph -->
    <meta name="twitter:card" content="summary_large_image" />
    <meta name="twitter:site" content="<?php echo e(config('brand.social_media.twitter')); ?>" />
    <meta name="twitter:creator" content="<?php echo e(config('brand.social_media.twitter')); ?>" />

    <meta property="og:url" content="<?php echo e(trailing_slash_it(url()->current())); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo e($title); ?>" />
    <meta property="og:description" content="<?php echo e($description); ?>" />
    <meta property="og:locale" content="<?php echo e(app()->getLocale()); ?>" />
    <meta property="og:site_name" content="<?php echo e(config('app.name')); ?>" />

    <?php if($ogImage): ?>
        <meta property="og:image" content="<?php echo e($ogImage->url); ?>" />
        <meta property="og:image:alt" content="<?php echo e($ogImage->alt); ?>" />
        <meta property="og:image:width" content="<?php echo e($ogImage->width); ?>" />
        <meta property="og:image:height" content="<?php echo e($ogImage->height); ?>" />
    <?php endif; ?>

    <?php echo $__env->yieldContent('meta'); ?>

    <?php if(!empty($fontsUrl)): ?>
        <link rel="preconnect" href="https://fonts.googleapis.com">
        <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
        <link href="<?php echo e($fontsUrl); ?>" rel="stylesheet" />

        <style>
            body {
                font-family: '<?php echo e($fontFamily); ?>', 'sans-serif';
            }
        </style>
    <?php endif; ?>

    <style>
        :root {
            <?php $__currentLoopData = $cssVariables ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cssVariableName => $cssVariableValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                --<?php echo e($cssVariableName); ?>: <?php echo e($cssVariableValue); ?>;
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        }
    </style>

    <?php echo $__env->yieldPushContent('styles'); ?>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.scss', 'resources/js/app.js']); ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::styles(); ?>

</head>

<body class="text-base text-slate-950 dark:text-white dark:bg-slate-900">
    <?php if (isset($component)) { $__componentOriginalc3b1af221f66830f793fed86a2d82051 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc3b1af221f66830f793fed86a2d82051 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.skip-link','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('skip-link'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc3b1af221f66830f793fed86a2d82051)): ?>
<?php $attributes = $__attributesOriginalc3b1af221f66830f793fed86a2d82051; ?>
<?php unset($__attributesOriginalc3b1af221f66830f793fed86a2d82051); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc3b1af221f66830f793fed86a2d82051)): ?>
<?php $component = $__componentOriginalc3b1af221f66830f793fed86a2d82051; ?>
<?php unset($__componentOriginalc3b1af221f66830f793fed86a2d82051); ?>
<?php endif; ?>

    <?php if (isset($component)) { $__componentOriginal6e8d2afe45e85f64be3746934dca3f97 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal6e8d2afe45e85f64be3746934dca3f97 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.headers.default','data' => ['siteSettings' => $siteSettings,'menu' => $menu]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('headers.default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['siteSettings' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siteSettings),'menu' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal6e8d2afe45e85f64be3746934dca3f97)): ?>
<?php $attributes = $__attributesOriginal6e8d2afe45e85f64be3746934dca3f97; ?>
<?php unset($__attributesOriginal6e8d2afe45e85f64be3746934dca3f97); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal6e8d2afe45e85f64be3746934dca3f97)): ?>
<?php $component = $__componentOriginal6e8d2afe45e85f64be3746934dca3f97; ?>
<?php unset($__componentOriginal6e8d2afe45e85f64be3746934dca3f97); ?>
<?php endif; ?>

    <?php echo $__env->yieldContent('hero'); ?>

    <?php echo e($slot); ?>


    <?php if (isset($component)) { $__componentOriginal3298954d1d88ae80ed6105de295a3d61 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal3298954d1d88ae80ed6105de295a3d61 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.footers.default','data' => ['siteSettings' => $siteSettings,'menu' => $menu]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('footers.default'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['siteSettings' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($siteSettings),'menu' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($menu)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal3298954d1d88ae80ed6105de295a3d61)): ?>
<?php $attributes = $__attributesOriginal3298954d1d88ae80ed6105de295a3d61; ?>
<?php unset($__attributesOriginal3298954d1d88ae80ed6105de295a3d61); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3298954d1d88ae80ed6105de295a3d61)): ?>
<?php $component = $__componentOriginal3298954d1d88ae80ed6105de295a3d61; ?>
<?php unset($__componentOriginal3298954d1d88ae80ed6105de295a3d61); ?>
<?php endif; ?>
    <?php if (isset($component)) { $__componentOriginal026c544cfb81717be117829402d47b5a = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal026c544cfb81717be117829402d47b5a = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.switch','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('switch'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Illuminate\View\AnonymousComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal026c544cfb81717be117829402d47b5a)): ?>
<?php $attributes = $__attributesOriginal026c544cfb81717be117829402d47b5a; ?>
<?php unset($__attributesOriginal026c544cfb81717be117829402d47b5a); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal026c544cfb81717be117829402d47b5a)): ?>
<?php $component = $__componentOriginal026c544cfb81717be117829402d47b5a; ?>
<?php unset($__componentOriginal026c544cfb81717be117829402d47b5a); ?>
<?php endif; ?>
    <?php echo \Livewire\Mechanisms\FrontendAssets\FrontendAssets::scripts(); ?>


    <?php echo $__env->yieldPushContent('scripts'); ?>
</body>

</html>
<?php /**PATH /home/abbasmashaddy72/Documents/Project-Sites/Testing/cms-quiz/resources/views/components/layouts/base.blade.php ENDPATH**/ ?>