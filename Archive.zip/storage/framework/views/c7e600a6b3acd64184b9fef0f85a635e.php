<footer class="relative text-gray-200 footer bg-slate-950 dark:text-gray-200">
    <div class="container">
        <div class="grid grid-cols-12">
            <div class="col-span-12">
                <div class="py-[60px] px-0">
                    <div class="grid grid-cols-1">
                        <div class="text-center">
                            <?php if(!empty($siteSettings->dark_logo) && !empty($siteSettings->light_logo)): ?>
                                <a class="<?php echo e(route('welcome')); ?>" href="<?php echo e(route('welcome')); ?>">
                                    <?php if (isset($component)) { $__componentOriginal2d62a2f0e3650962aee0f8158be82357 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2d62a2f0e3650962aee0f8158be82357 = $attributes; } ?>
<?php $component = Awcodes\Curator\View\Components\Glider::resolve(['media' => $siteSettings->light_logo,'srcset' => ['1200w', '1024w', '640w'],'sizes' => '(max-width: 1200px) 100vw, 1024px'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('curator-glider'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(Awcodes\Curator\View\Components\Glider::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes(['class' => 'block w-auto h-24 mx-auto']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2d62a2f0e3650962aee0f8158be82357)): ?>
<?php $attributes = $__attributesOriginal2d62a2f0e3650962aee0f8158be82357; ?>
<?php unset($__attributesOriginal2d62a2f0e3650962aee0f8158be82357); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2d62a2f0e3650962aee0f8158be82357)): ?>
<?php $component = $__componentOriginal2d62a2f0e3650962aee0f8158be82357; ?>
<?php unset($__componentOriginal2d62a2f0e3650962aee0f8158be82357); ?>
<?php endif; ?>
                                </a>
                            <?php else: ?>
                                <a class="<?php echo e(route('welcome')); ?>" href="<?php echo e(route('welcome')); ?>">
                                    <span
                                        class="block w-auto mx-auto text-5xl text-white"><?php echo e(config('app.name')); ?></span>
                                </a>
                            <?php endif; ?>
                            <p class="max-w-xl mx-auto mt-8 text-slate-500 dark:text-slate-300">
                                <?php echo e($siteSettings->description); ?></p>
                        </div>

                        <ul class="mt-8 space-x-2 text-center list-none footer-list">
                            <?php $__currentLoopData = $menu->where('location', 'footer1')->pluck('items'); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $items): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $translation): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <li class="inline px-2">
                                        <a class="text-gray-300 duration-500 ease-in-out hover:text-gray-400"
                                            <?php if($translation['blank']): ?> target="__blank" <?php endif; ?>
                                            href="<?php echo e($translation['url']); ?>"><?php echo e($translation['title']); ?></a>
                                    </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <div class="py-[30px] px-0 border-t border-slate-800">
        <div class="container text-center">
            <div class="grid items-center md:grid-cols-12">
                <div class="md:col-span-6">
                    <div class="text-center md:text-start">
                        <p class="text-gray-400">© <?php echo e(date('Y')); ?>. All rights are belonging to
                            <?php echo e(config('app.name')); ?>.
                        </p>
                    </div>
                </div>

                <div class="mt-8 md:col-span-6 md:mt-0">
                    <ul class="text-center list-none md:text-end">
                        <?php $__currentLoopData = $siteSettings->social; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="inline">
                                <a href="<?php echo e($item['link']); ?>" target="_blank"
                                    class="inline-flex items-center justify-center w-8 h-8 text-base font-normal tracking-wide text-center align-middle transition duration-500 ease-in-out border border-gray-800 rounded-md hover:border-primary-400 dark:hover:border-primary-400 hover:bg-primary-400 dark:hover:bg-primary-400">
                                    <i class="align-middle <?php echo e($item['icon']); ?>"
                                        title="<?php echo e(ucfirst($item['platform'])); ?>"></i>
                                </a>
                            </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</footer>
<?php /**PATH /home/abbasmashaddy72/Documents/Project-Sites/Testing/cms-quiz/resources/views/components/footers/default.blade.php ENDPATH**/ ?>