<?php

return [
    'skip_link' => 'Skip to main content',
];
